#ifndef KESTREL_CORE_KESTREL_DEFINE_H
#define KESTREL_CORE_KESTREL_DEFINE_H

#include <stdint.h>
#include <stdlib.h>
#include <string.h>

// Determines the platform on which Kestrel is compiled.
#ifdef __EMSCRIPTEN__
#define KESTREL_OS_EMSCRIPTEN 1
#elif defined __CYGWIN__
#define KESTREL_OS_CYGWIN 1
#elif defined __SYMBIAN32__
#define KESTREL_OS_SYMBIAN 1
#elif defined _WIN32
#define KESTREL_OS_WINDOWS 1
#if defined(__MINGW__) || defined(__MINGW32__)
#define KESTREL_OS_WINDOWS_MINGW 1
#else
#define KESTREL_OS_WINDOWS_DESKTOP 1
#endif
#elif defined __APPLE__
#include <TargetConditionals.h>
#define KESTREL_OS_MAC 1
#if TARGET_OS_IPHONE
#define KESTREL_OS_IOS 1
#endif
#elif defined __FreeBSD__
#define KESTREL_OS_FREEBSD 1
#elif defined __linux__
#define KESTREL_OS_LINUX 1
#if defined __ANDROID__
#define KESTREL_OS_LINUX_ANDROID 1
#endif
#elif defined __MVS__
#define KESTREL_OS_ZOS 1
#elif defined(__sun) && defined(__SVR4)
#define KESTREL_OS_SOLARIS 1
#elif defined(_AIX)
#define KESTREL_OS_AIX 1
#elif defined(__hpux)
#define KESTREL_OS_HPUX 1
#elif defined __native_client__
#define KESTREL_OS_NACL 1
#elif defined __OpenBSD__
#define KESTREL_OS_OPENBSD 1
#elif defined __QNX__
#define KESTREL_OS_QNX 1
#endif // __CYGWIN__

#ifdef KESTREL_STATIC
#define KESTREL_API_
#define KESTREL_DEPRECATED
#define KESTREL_DONOTINLINE
#else
#if KESTREL_OS_WINDOWS
#ifdef KESTREL_BUILD
#define KESTREL_API_ __declspec(dllexport)
#else
#define KESTREL_API_ //__declspec(dllimport)
#endif
#define KESTREL_DEPRECATED __declspec(deprecated)
#define KESTREL_DONOTINLINE __declspec(noinline)
#else
#if defined(__GNUC__) && __GNUC__ >= 4
#define KESTREL_API_ __attribute__((visibility("default")))
#define KESTREL_DEPRECATED __attribute__((deprecated))
#define KESTREL_DONOTINLINE __attribute__((noinline))
#else
#if __EMSCRIPTEN__
#define KESTREL_API_ __attribute__((used))
#define KESTREL_DEPRECATED __attribute__((deprecated))
#define KESTREL_DONOTINLINE __attribute__((noinline))
#else
#define KESTREL_API_
#define KESTREL_DEPRECATED
#define KESTREL_DONOTINLINE
#endif
#endif
#endif
#endif

#ifdef __cplusplus
#define KESTREL_API extern "C" KESTREL_API_
#else
#define KESTREL_API KESTREL_API_
#endif

///
/// Kestrel error code type
///
typedef int k_err;

#define CV_ERR_PACK(lib, module, reason)                                                         \
        ((int)(0x80000000 | ((unsigned int)(lib)&0x7ff) << 20 |                                  \
               ((unsigned int)(module)&0xf) << 16 | ((unsigned int)(reason)&0xffff)))

#define CV_ERR_GETLIB(error_code) ((unsigned int)(error_code) >> 20 & 0x7ff)

#define CV_ERR_GETMODULE(error_code) ((unsigned int)(error_code) >> 16 & 0xf)

#define CV_ERR_GETREASON(error_code) ((unsigned int)(error_code)&0xffff)

///====================global error definition==========================================
#define CV_E_GLOBAL_LIB 0x7ff
#define CV_E_GLOBAL_MODULE 0xf
#define CV_E_ONLINE_ACTIVATE_MODULE 0xe
#define CV_E_CONNECTION_MODULE 0xd

#define CV_E_INVALIDARG CV_ERR_PACK(CV_E_GLOBAL_LIB, CV_E_GLOBAL_MODULE, 0xffff) // -1
#define CV_E_HANDLE CV_ERR_PACK(CV_E_GLOBAL_LIB, CV_E_GLOBAL_MODULE, 0xfffe) // -2
#define CV_E_OUTOFMEMORY CV_ERR_PACK(CV_E_GLOBAL_LIB, CV_E_GLOBAL_MODULE, 0xfffd) // -3
#define CV_E_FAIL CV_ERR_PACK(CV_E_GLOBAL_LIB, CV_E_GLOBAL_MODULE, 0xfffc) // -4
#define CV_E_DELNOTFOUND CV_ERR_PACK(CV_E_GLOBAL_LIB, CV_E_GLOBAL_MODULE, 0xfffb) // -5
#define CV_E_INVALID_PIXEL_FORMAT CV_ERR_PACK(CV_E_GLOBAL_LIB, CV_E_GLOBAL_MODULE, 0xfffa) // -6
#define CV_E_FILE_NOT_FOUND CV_ERR_PACK(CV_E_GLOBAL_LIB, CV_E_GLOBAL_MODULE, 0xfff9) // -7
#define CV_E_INVALID_FILE_FORMAT CV_ERR_PACK(CV_E_GLOBAL_LIB, CV_E_GLOBAL_MODULE, 0xfff8) // -8
#define CV_E_UNSUPPORTED CV_ERR_PACK(CV_E_GLOBAL_LIB, CV_E_GLOBAL_MODULE, 0xfc18) // -1000

#define CV_E_FILE_EXPIRE CV_ERR_PACK(CV_E_GLOBAL_LIB, CV_E_GLOBAL_MODULE, 0xfff7) // -9
#define CV_E_READ_FILE_FAIL CV_ERR_PACK(CV_E_GLOBAL_LIB, CV_E_GLOBAL_MODULE, 0xfff6) // -10
#define CV_E_VERIFY_REG_FAIL CV_ERR_PACK(CV_E_GLOBAL_LIB, CV_E_GLOBAL_MODULE, 0xfff5) // -11

#define CV_E_INVALID_AUTH CV_ERR_PACK(CV_E_GLOBAL_LIB, CV_E_GLOBAL_MODULE, 0xfff3) // -13
#define CV_E_INVALID_APPID CV_ERR_PACK(CV_E_GLOBAL_LIB, CV_E_GLOBAL_MODULE, 0xfff2) // -14
#define CV_E_AUTH_EXPIRE CV_ERR_PACK(CV_E_GLOBAL_LIB, CV_E_GLOBAL_MODULE, 0xfff1) // -15
#define CV_E_UUID_MISMATCH CV_ERR_PACK(CV_E_GLOBAL_LIB, CV_E_GLOBAL_MODULE, 0xfff0) // -16
#define CV_E_ONLINE_AUTH_CONNECT_FAIL                                                            \
        CV_ERR_PACK(CV_E_GLOBAL_LIB, CV_E_GLOBAL_MODULE, 0xffef) // -17
#define CV_E_ONLINE_AUTH_TIMEOUT CV_ERR_PACK(CV_E_GLOBAL_LIB, CV_E_GLOBAL_MODULE, 0xffee) // -18
#define CV_E_ONLINE_AUTH_INVALID CV_ERR_PACK(CV_E_GLOBAL_LIB, CV_E_GLOBAL_MODULE, 0xffed) // -19
#define CV_E_LICENSE_IS_NOT_ACTIVABLE                                                            \
        CV_ERR_PACK(CV_E_GLOBAL_LIB, CV_E_GLOBAL_MODULE, 0xffec) // -20
#define CV_E_ACTIVE_FAIL CV_ERR_PACK(CV_E_GLOBAL_LIB, CV_E_GLOBAL_MODULE, 0xffeb) // -21
#define CV_E_ACTIVE_CODE_INVALID CV_ERR_PACK(CV_E_GLOBAL_LIB, CV_E_GLOBAL_MODULE, 0xffea) // -22
#define CV_E_PRODUCT_VERSION_MISMATCH                                                            \
        CV_ERR_PACK(CV_E_GLOBAL_LIB, CV_E_GLOBAL_MODULE, 0xffe9) // -23
#define CV_E_PLATFORM_NOTSUPPORTED CV_ERR_PACK(CV_E_GLOBAL_LIB, CV_E_GLOBAL_MODULE, 0xffe8) // -24
#define CV_E_UNZIP_FAILED CV_ERR_PACK(CV_E_GLOBAL_LIB, CV_E_GLOBAL_MODULE, 0xffe7) // -25
#define CV_E_SUBMODULE_NON_EXIT CV_ERR_PACK(CV_E_GLOBAL_LIB, CV_E_GLOBAL_MODULE, 0xffe6) // -26
#define CV_E_ONLINE_ACTIVATE_NO_NEED                                                             \
        CV_ERR_PACK(CV_E_GLOBAL_LIB, CV_E_GLOBAL_MODULE, 0xffe5) // -27
#define CV_E_ONLINE_ACTIVATE_FAIL CV_ERR_PACK(CV_E_GLOBAL_LIB, CV_E_GLOBAL_MODULE, 0xffe4) // -28
#define CV_E_ONLINE_ACTIVATE_CODE_INVALID                                                        \
        CV_ERR_PACK(CV_E_GLOBAL_LIB, CV_E_GLOBAL_MODULE, 0xffe3) // -29
#define CV_E_ONLINE_ACTIVATE_CONNECT_FAIL                                                        \
        CV_ERR_PACK(CV_E_GLOBAL_LIB, CV_E_GLOBAL_MODULE, 0xffe2) // -30
#define CV_RET_UNRECOGNIZED CV_ERR_PACK(CV_E_GLOBAL_LIB, CV_E_GLOBAL_MODULE, 0xffe1) // -31
#define CV_E_HW_AUTH_INIT_FAIL CV_ERR_PACK(CV_E_GLOBAL_LIB, CV_E_GLOBAL_MODULE, 0xffe0) // -32
#define CV_E_HW_AUTH_FAIL CV_ERR_PACK(CV_E_GLOBAL_LIB, CV_E_GLOBAL_MODULE, 0xffdf) // -33
#define CV_E_VERIFY_FAIL CV_ERR_PACK(CV_E_GLOBAL_LIB, CV_E_GLOBAL_MODULE, 0xffde) // -34
#define CV_E_VERIFY_EXPIRE CV_ERR_PACK(CV_E_GLOBAL_LIB, CV_E_GLOBAL_MODULE, 0xffdd) // -35
#define CV_E_NO_LICENSE CV_ERR_PACK(CV_E_GLOBAL_LIB, CV_E_GLOBAL_MODULE, 0xffdc) // -36
#define CV_E_HW_REG_FAIL CV_ERR_PACK(CV_E_GLOBAL_LIB, CV_E_GLOBAL_MODULE, 0xffdb) // -37
#define CV_E_PRODUCT_VERSION_FAILED                                                              \
        CV_ERR_PACK(CV_E_GLOBAL_LIB, CV_E_GLOBAL_MODULE, 0xffda) // -38
#define CV_E_LIB_EXIST CV_ERR_PACK(CV_E_GLOBAL_LIB, CV_E_GLOBAL_MODULE, 0xffd9)
/*
 * Connection error module code
 */
#define CV_E_CONNECTION_FAIL CV_ERR_PACK(CV_E_GLOBAL_LIB, CV_E_CONNECTION_MODULE, 0xffff)

///=======================protector errors===========================================
#define CV_E_PROTECTOR_LIB 0x1
#define CV_E_LICENSE_LIB 0x7F // 127
#define CV_E_PROTECTOR_MODULE_ONLINEAUTH_MODULE 0x1
#define CV_E_LICENSE_SENTINEL_MODULE 0x0

#define CV_E_PROTECTOR_UDID                                                                      \
        CV_ERR_PACK(CV_E_PROTECTOR_LIB, CV_E_PROTECTOR_MODULE_ONLINEAUTH_MODULE, 0xffff)
#define CV_E_PROTECTOR_FORMAT_HEADER                                                             \
        CV_ERR_PACK(CV_E_PROTECTOR_LIB, CV_E_PROTECTOR_MODULE_ONLINEAUTH_MODULE, 0xfffe)
#define CV_E_PROTECTOR_INVALID_URL                                                               \
        CV_ERR_PACK(CV_E_PROTECTOR_LIB, CV_E_PROTECTOR_MODULE_ONLINEAUTH_MODULE, 0xfffd)

#define CV_E_HEARTBEAT_CONNECT_FAIL CV_ERR_PACK(CV_E_PROTECTOR_LIB, CV_E_GLOBAL_MODULE, 0xffff)
#define CV_E_HEARTBEAT_INVALID_RESPONSE                                                          \
        CV_ERR_PACK(CV_E_PROTECTOR_LIB, CV_E_GLOBAL_MODULE, 0xfffe)

#define CV_E_SENTINEL_PARSE_XML                                                                  \
        CV_ERR_PACK(CV_E_LICENSE_LIB, CV_E_LICENSE_SENTINEL_MODULE, 0x8000)
#define CV_E_SENTINEL_CONNECT_FAIL                                                               \
        CV_ERR_PACK(CV_E_LICENSE_LIB, CV_E_LICENSE_SENTINEL_MODULE, 0x8001)
#define CV_E_SENTINEL_V2C_MISSING                                                                \
        CV_ERR_PACK(CV_E_LICENSE_LIB, CV_E_LICENSE_SENTINEL_MODULE, 0x8002)
#define CV_E_SENTINEL_INVALID_RESPONSE                                                           \
        CV_ERR_PACK(CV_E_LICENSE_LIB, CV_E_LICENSE_SENTINEL_MODULE, 0x8003)
#define CV_E_SENTINEL_FINGERPRINT_MISMATCH                                                       \
        CV_ERR_PACK(CV_E_LICENSE_LIB, CV_E_LICENSE_SENTINEL_MODULE, 0x8004)

#define KESTREL_ERR 0x4B
#define KESTREL_E_CORE 0x00

#define KESTREL_OK 0

#define KESTREL_UNUSED(x) (void)(x)

///
/// Kestrel event handle
///
typedef void *kestrel_event;

#if KESTREL_OS_WINDOWS_DESKTOP
#define HAVE_STRUCT_TIMESPEC
#endif

#ifdef __cplusplus

#if KESTREL_OS_WINDOWS_DESKTOP
#if defined(_MSC_FULL_VER) && _MSC_FULL_VER >= 190023026
#define HAS_NOEXCEPT
#define HAS_CONSTEXPR
#endif
#elif defined(__clang__)
#if __has_feature(cxx_noexcept)
#define HAS_NOEXCEPT
#endif
#if __has_feature(cxx_constexpr)
#define HAS_CONSTEXPR
#endif
#else // Default assumption: GCC 4.9 or higher
#define HAS_NOEXCEPT
#define HAS_CONSTEXPR
#endif

#ifdef HAS_NOEXCEPT
#define NOEXCEPT noexcept
#else
#define NOEXCEPT
#endif

#ifdef HAS_CONSTEXPR
#define CONSTEXPR constexpr
#define CONSTEXPR_OR_CONST constexpr
#else
#define CONSTEXPR
#define CONSTEXPR_OR_CONST const
#endif

#endif

#endif
