#ifndef KESTREL_CORE_KESTREL_LICENSE_H
#define KESTREL_CORE_KESTREL_LICENSE_H

#include "kestrel_define.h"

#ifdef __cplusplus
extern "C" {
#endif

/// @addtogroup kestrel_license
///
/// Kestrel license supports [SenseTime License System](http://license.sensetime.com), where the
/// user could apply for license files from, and use it for Kestrel.
///
/// @{

/// License UDID getter callback
/// @param[in] udid User provided UDID string buffer
/// @param[in,out] len UDID buffer length, after invoke it is the real length of UDID
/// @return KESTREL_OK for succeed, other for error
typedef k_err (*kestrel_udid_getter)(char *udid, size_t *len);

KESTREL_API
k_err udid_default_getter(char *udid, size_t *buf_size);

/// @brief Set License UDID getter function
/// @param[in] getter UDID getter function
KESTREL_API
void kestrel_license_set_udid_getter(kestrel_udid_getter getter);

/// @brief Reset License UDID getter function
/// @note Kestrel uses encrypted UDID getter function as default.
KESTREL_API
void kestrel_license_reset_udid_getter();

///
/// Verifier command code for auth
///
typedef enum kestrel_license_verifier_cmd_e {
        KESTREL_LICENSE_VERIFIER_CMD_READ_SN,
        KESTREL_LICENSE_VERIFIER_CMD_READ_OTP,
        KESTREL_LICENSE_VERIFIER_CMD_NONCE,
        KESTREL_LICENSE_VERIFIER_CMD_MAC,
        KESTREL_LICENSE_VERIFIER_CMD_SLOT_ID
} kestrel_license_verifier_cmd_e;

///
/// Verifier commend body definition
///
typedef struct kestrel_license_verify_t {
        kestrel_license_verifier_cmd_e command;
        uint8_t address;
        uint8_t data_len;
        uint8_t *data;
} kestrel_license_verify_t;

///
/// Verifier communication function definition
///
typedef k_err (*kestrel_license_verifier_fx)(const kestrel_license_verify_t *req,
                                             unsigned char *resp_data, int *resp_len);

/// @brief Set verifier communication interface
/// @param[in] verifier Auth communication function
/// @return KESTREL_OK for succeed, other for error
KESTREL_API
k_err kestrel_license_set_verifier(kestrel_license_verifier_fx verifier);

/// @brief Add license for spec Kestrel environment
/// @param[in] license License string
/// @param[in] signed_code Signature code for license, if not used, set it NULL
/// @return KESTREL_OK for succeed, other for error
KESTREL_API
k_err kestrel_license_add(const char *license, const char *signed_code);

/// @brief Similar with kestrel_license_add(), but read license form file
/// @param[in] license_file License file path
/// @param[in] signed_code Signature code for license, if not used, set it NULL
/// @return KESTREL_OK for succeed, other for error
KESTREL_API
k_err kestrel_license_add_from_file(const char *license_file, const char *signed_code);

/// @brief Get user ID in license
/// @return Zero terminated user ID string, should be freed using free()
KESTREL_API
char *kestrel_license_user_id();

/// @brief Get UDID by udid_getter
/// @return Zero terminated UDID string, should be freed using free()
KESTREL_API
char *kestrel_license_get_udid();

///
/// Max product version length
///
#define MAX_PRODUCT_VERSION_LENGTH 100

///
/// Product version getter definition
///
typedef k_err (*kestrel_product_version_getter)(char product_version[MAX_PRODUCT_VERSION_LENGTH]);

/// @brief Get product_version by product_version_getter
/// @param[in] product_version User provided buffer
/// @return KESTREL_OK for succeed, other for error
KESTREL_API
k_err kestrel_license_get_product_version(char product_version[MAX_PRODUCT_VERSION_LENGTH]);

/// @brief Set License product version getter function
/// @param[in] getter Product version getter function
KESTREL_API
void kestrel_license_set_product_version_getter(kestrel_product_version_getter getter);

/// @brief Reset License product version getter function
KESTREL_API
void kestrel_license_reset_product_version_getter();

/// @brief Get License time limit
/// @param[out] start Time start
/// @param[out] end Time end
KESTREL_API
k_err kestrel_license_get_time_limit(int *start, int *end);

/// @brief Get License serial number
/// @return Zero terminated serial number string, should be freed using free()
KESTREL_API
char *kestrel_license_get_sn();

/// @brief Check License capability
/// @param[in] capability Key name of required capability
/// @return KESTREL_OK for succeed, Negative for error
KESTREL_API
k_err kestrel_license_has_capability(const char *capability);

/// @brief Check License has UUID
/// @return 1 for succeed, otherwise 0
KESTREL_API
int32_t kestrel_license_has_uuid();

/// @brief Get limit option value in license of which key name is `item`
/// @param[in] item Key name of required option
/// @return Negative for error, else return limit option value
KESTREL_API
int32_t kestrel_license_get_limit(const char *item);

/// @brief Get limit option string in license of which key name is `item`
/// @param[in] item Key name of required option
/// @return Zero terminated serial number string, should be freed using free()
KESTREL_API
char *kestrel_license_get_limit_str(const char *item);

/// @brief Check in a limit counter which key name is `item`
/// @param[in] item Key name going to be checked in
/// @return KESTREL_OK for succeed, other for error
KESTREL_API
k_err kestrel_license_checkin(const char *item);

/// @brief Check out a limit counter which key name is `item`
/// @param[in] item Key name going to be checked out
KESTREL_API
void kestrel_license_checkout(const char *item);

/// @brief Get online activation code
/// @param[in] product_name Product name
/// @param[in] license License string
/// @param[in] time_expire License expire time
/// @param[out] signed_code Online activation code, you should destroy the result by free()
/// @return KESTREL_OK for succeed, other for error
KESTREL_API
k_err kestrel_license_get_online_activation_code(const char *license, uint64_t time_expire,
                                                 char **signed_code, size_t *signed_code_len);

/// @brief [Deprecated] Preview license content
/// @param[in] product_name Product name
/// @param[in] license License string
/// @param[out] info License information string, you should destroy the result by free()
/// @return KESTREL_OK for succeed, other for error
KESTREL_API
k_err kestrel_license_preview(const char *product_name, const char *license, char **info);

/// @brief Preview Check License has UUID
/// @return 1 for succeed, otherwise 0
KESTREL_API
int32_t kestrel_license_preview_has_uuid(const char *product_name, const char *license);

/// @brief Preview License online authtype
/// @param[in] product_name Product name
/// @param[in] license_string License string
/// @param[out] type 0(no_auth), 1(verify_v1), 2(verify_v2), 3(online_activation),
/// 4(offline_activation), 5(ca_private), 6(qr_activation), 7(ctl_activation)
/// @return KESTREL_OK for succeed, other for error
KESTREL_API
k_err kestrel_license_preview_get_authtype(const char *product_name, const char *license,
                                           int *type);

/// @brief Preview Get limit option value in license of which key name is `item`
/// @param[in] product_name Product name
/// @param[in] license_string License string
/// @param[in] item Key name of required option
/// @return Negative for error, else return limit option value
KESTREL_API
int kestrel_license_preview_get_limit(const char *product_name, const char *license,
                                      const char *item);

/// @brief Preview Get limit option string in license of which key name is `item`
/// @param[in] product_name Product name
/// @param[in] license_string License string
/// @param[in] item Key name of required option
/// @return Zero terminated serial number string, should be freed using free()
KESTREL_API
char *kestrel_license_preview_get_limit_str(const char *product_name, const char *license,
                                            const char *item);
/// @}

#ifdef __cplusplus
}
#endif

#endif
