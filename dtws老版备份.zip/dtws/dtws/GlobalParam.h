#pragma once

enum
{
	USER,
	PASSWORD
};