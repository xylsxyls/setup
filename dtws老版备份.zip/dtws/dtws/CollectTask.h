#pragma once
#include "BaseTask.h"

class CollectTask : public BaseTask
{
public:
	void DoTask();
};