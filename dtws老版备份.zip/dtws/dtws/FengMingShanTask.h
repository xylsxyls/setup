#pragma once
#include "CTaskThreadManager/CTaskThreadManagerAPI.h"
#include <string>
#include "BaseTask.h"

class FengMingShanTask : public BaseTask
{
public:
	void DoTask();
};