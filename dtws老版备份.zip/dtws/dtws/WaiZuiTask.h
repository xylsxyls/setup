#pragma once
#include "CTaskThreadManager/CTaskThreadManagerAPI.h"
#include <string>
#include "BaseTask.h"

class WaiZuiTask : public BaseTask
{
public:
	void DoTask();
};