#pragma once
#include "CTaskThreadManager/CTaskThreadManagerAPI.h"
#include <string>
#include "BaseTask.h"

class TieQiangTask : public BaseTask
{
public:
	void DoTask();
};