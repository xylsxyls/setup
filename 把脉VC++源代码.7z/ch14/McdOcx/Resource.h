//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by McdOcx.rc
//

#define IDS_MCDOCX               1
#define IDS_MCDOCX_PPG           2

#define IDS_MCDOCX_PPG_CAPTION   200

#define IDD_PROPPAGE_MCDOCX      200

#define IDD_ABOUTBOX_MCDOCX      1

#define IDB_MCDOCX               1

#define IDI_ABOUTDLL				1

#define _APS_NEXT_RESOURCE_VALUE        201
#define _APS_NEXT_CONTROL_VALUE         201
#define _APS_NEXT_SYMED_VALUE           101
#define _APS_NEXT_COMMAND_VALUE         32768
