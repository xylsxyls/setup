// MobilePhoneComTest.cpp : �������̨Ӧ�ó������ڵ㡣
//

#include "stdafx.h"
#include "comutil.h"
#include <iostream>
using namespace std;

#import "..\\MobilePhoneCom\\Debug\\MobilePhoneCom.dll"

int _tmain()
{
	HRESULT hr = CoInitialize(NULL);
	if(SUCCEEDED(hr))
	{
		MobilePhoneComLib::IMobilePhonePtr ptrMobilePhone;
		if(SUCCEEDED(ptrMobilePhone.CreateInstance(__uuidof(MobilePhoneComLib::MobilePhone))))
		{
			BSTR bstr = ptrMobilePhone->getName().Detach();
			_bstr_t cb = bstr;

			cout << "��������: " << (char *)cb << endl;
			ptrMobilePhone->talk();
		}
	}

	CoUninitialize();
	return 0;
}

