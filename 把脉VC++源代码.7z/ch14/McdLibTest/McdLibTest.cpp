#include "stdafx.h"
#include "../../shared/mcd.h"
#pragma comment(lib, "../Debug/McdLib.lib")

int _tmain()
{
	printf("%d\r\n", mcd(16, 24));
	return 0;
}