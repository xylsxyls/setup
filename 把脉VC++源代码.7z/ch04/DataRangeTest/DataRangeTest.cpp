#include "stdafx.h"
#include <climits>

int main()
{
	printf("MB_LEN_MAX: %ld\r\n", MB_LEN_MAX);
	printf("INT_MAX: %x\r\n", INT_MAX);
	printf("UINT_MAX: %x\r\n", UINT_MAX);
	printf("_I64_MAX: %x\r\n", _I64_MAX);

	return 0;
}

