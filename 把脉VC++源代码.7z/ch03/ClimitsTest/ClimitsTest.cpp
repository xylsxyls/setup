#include "stdafx.h"
#include <climits>

int main()
{
	printf("MB_LEN_MAX: %ld\r\n", MB_LEN_MAX);
	printf("INT_MAX: %X\r\n", INT_MAX);
	printf("UINT_MAX: %X\r\n", UINT_MAX);
	printf("_I64_MAX: %X\r\n", _I64_MAX);

	return 0;
}