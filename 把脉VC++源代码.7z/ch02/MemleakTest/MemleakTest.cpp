#include "stdafx.h"

int main()
{
	int * ip = new int;
	return 0;
}
