#include "stdafx.h"

int main()
{
	float i = 100;

	for(int i = 0; i < 10; i++)
	{
	}

	for(char i = 'a'; i <= 'z'; i++)
	{
	}

	return 0;
}