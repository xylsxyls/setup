#include "BackgroundLabel.h"

BackgroundLabel::BackgroundLabel(QWidget* parent):
Label(parent)
{

}

BackgroundLabel::~BackgroundLabel()
{

}