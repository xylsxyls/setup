#include "Locator.h"

ACEXML_Locator::~ACEXML_Locator (void)
{
}
