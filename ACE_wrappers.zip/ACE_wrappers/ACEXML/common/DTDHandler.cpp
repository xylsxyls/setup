#include "DTDHandler.h"

ACEXML_DTDHandler::~ACEXML_DTDHandler (void)
{
}
