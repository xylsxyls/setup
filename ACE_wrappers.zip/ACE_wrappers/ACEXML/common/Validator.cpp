#include "ACEXML/common/Validator.h"

ACEXML_Validator::~ACEXML_Validator ()
{

}
