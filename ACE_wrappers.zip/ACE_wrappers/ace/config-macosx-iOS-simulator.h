#ifndef ACE_CONFIG_MACOSX_IPHONE_SIMULATOR_H
#define ACE_CONFIG_MACOSX_IPHONE_SIMULATOR_H

#define ACE_HAS_IPHONE
#include "ace/config-macosx-mavericks.h"

#endif /* ACE_CONFIG_MACOSX_IPHONE_SIMULATOR_H */

