#ifndef ACE_CONFIG_MACOSX_MOUNTAINLION_H
#define ACE_CONFIG_MACOSX_MOUNTAINLION_H

// Deprecated
#ifndef ACE_LACKS_SBRK
#define ACE_LACKS_SBRK
#endif

// Deprecated
#ifndef ACE_LACKS_TEMPNAM
#define ACE_LACKS_TEMPNAM
#endif

#include "ace/config-macosx-lion.h"

#endif // ACE_CONFIG_MACOSX_MOUNTAIN_LION_H
