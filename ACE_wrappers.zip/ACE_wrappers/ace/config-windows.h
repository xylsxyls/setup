/* -*- C++ -*- */
// This is all we need to do to build ACE on a Windows platform (32bit or 64bit)
#include "config-win32.h"
